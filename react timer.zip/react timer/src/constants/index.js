export const TIMER = "TIMER";
export const COUNTDOWN = "COUNTDOWN";

//Redux actions
export const TEST = "TEST";

export const ADD_TIME = "ADD_TIME";
export const DELETE_TIME = "DELETE_TIME";
